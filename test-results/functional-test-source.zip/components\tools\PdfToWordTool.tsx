"use client";

import { useState } from "react";
import { ClipboardCopy, Download, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FileUploader, type UploadedFile } from "./FileUploader";
import { CancelOperationButton } from "./CancelOperationButton";
import { useOperationCancellation } from "./useOperationCancellation";
import { copyText, downloadBlob, shortId } from "@/lib/download";
import { throwIfCancelled } from "@/lib/file-validation";

/**
 * PDF to Word tool.
 *
 * Uses pdfjs-dist to extract text content from each page of the PDF, then
 * wraps that text in a minimal Word-compatible .doc file (HTML-based Word
 * 97-2003 format that opens in Word, Google Docs, and LibreOffice).
 *
 * Note: This focuses on accurate text extraction. Complex layouts, tables,
 * and images are NOT preserved.
 */
export function PdfToWordTool() {
  const [file, setFile] = useState<UploadedFile | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [extractedText, setExtractedText] = useState<string>("");
  const [clipboardStatus, setClipboardStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const cancellation = useOperationCancellation();

  const handleFilesAdded = (newFiles: File[]) => {
    if (newFiles.length === 0) return;
    const f = newFiles[0];
    if (!f.name.toLowerCase().endsWith(".pdf")) {
      setError("Please upload a PDF file.");
      return;
    }
    setError(null);
    setFile({ file: f, id: shortId() });
    setExtractedText("");
    setClipboardStatus(null);
  };

  const handleRemove = () => {
    setFile(null);
    setExtractedText("");
    setClipboardStatus(null);
  };

  const handleProcessAnotherFile = () => {
    setFile(null);
    setExtractedText("");
    setError(null);
    setProgress(0);
    setClipboardStatus(null);
  };

  const handleConvert = async () => {
    if (!file) return;
    setIsProcessing(true);
    setError(null);
    setProgress(0);
    setExtractedText("");
    setClipboardStatus(null);
    const controller = cancellation.start();

    try {
      throwIfCancelled(controller.signal);
      // Lazy-load pdfjs-dist so the heavy WASM only loads when needed.
      const pdfjs = await import("pdfjs-dist/build/pdf.mjs");
      // Use a worker URL via webpack's new URL() support (Next.js compatible).
      pdfjs.GlobalWorkerOptions.workerSrc = new URL(
        "pdfjs-dist/build/pdf.worker.mjs",
        import.meta.url
      ).toString();

      const buf = await file.file.arrayBuffer();
      throwIfCancelled(controller.signal);
      const doc = await pdfjs.getDocument({ data: buf }).promise;
      const lines: string[] = [];
      for (let i = 1; i <= doc.numPages; i++) {
        throwIfCancelled(controller.signal);
        const page = await doc.getPage(i);
        const content = await page.getTextContent();
        throwIfCancelled(controller.signal);
        const text = content.items
          .map((item) => ("str" in item ? (item as { str: string }).str : ""))
          .join(" ");
        lines.push(text);
        setProgress(Math.round((i / doc.numPages) * 100));
      }
      throwIfCancelled(controller.signal);
      const fullText = lines.join("\n\n");
      setExtractedText(fullText);
    } catch (err) {
      if (controller.signal.aborted) {
        setError("Conversion cancelled. No partial document was created.");
      } else {
        console.error(err);
        setError(
          "Failed to extract text. The PDF may be scanned (images only) or corrupted."
        );
      }
    } finally {
      cancellation.finish(controller);
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!extractedText || !file) return;
    const baseName = file.file.name.replace(/\.pdf$/i, "");
    // Build a minimal Word-compatible .doc file (HTML format that Word reads).
    const escaped = extractedText
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    const paragraphs = escaped
      .split(/\n\n+/)
      .map((p) => `<p>${p.replace(/\n/g, "<br/>")}</p>`)
      .join("");
    const html = `<!DOCTYPE html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>${baseName}</title></head><body>${paragraphs}</body></html>`;
    const blob = new Blob([html], { type: "application/msword" });
    downloadBlob(blob, `${baseName}.doc`);
  };

  const handleCopyText = async () => {
    const copied = await copyText(extractedText);
    setClipboardStatus(
      copied
        ? "Text copied to clipboard."
        : "Could not copy text. Select it from the preview and copy manually.",
    );
  };

  const handleDownloadText = () => {
    if (!extractedText || !file) return;
    const baseName = file.file.name.replace(/\.pdf$/i, "");
    const blob = new Blob([extractedText], { type: "text/plain;charset=utf-8" });
    downloadBlob(blob, `${baseName}.txt`);
  };

  return (
    <div className="space-y-5">
      <FileUploader
        accept="application/pdf,.pdf"
        files={file ? [file] : []}
        onFilesAdded={handleFilesAdded}
        onFileRemove={handleRemove}
        hint="Upload a PDF with embedded text. Scanned PDFs (images only) are not supported."
        disabled={isProcessing}
      />

      {error && (
        <p className="rounded-md bg-destructive/10 p-3 text-sm text-destructive" role="alert">
          {error}
        </p>
      )}

      {isProcessing && (
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">
              {cancellation.isCancelling
                ? "Stopping after the current page..."
                : `Extracting text... ${progress}%`}
            </p>
            <CancelOperationButton
              onCancel={cancellation.cancel}
              isCancelling={cancellation.isCancelling}
              cancelLabel="Cancel after this page"
              cancellingLabel="Stopping after this page..."
            />
          </div>
          <Progress value={progress} />
        </div>
      )}

      <Button
        onClick={handleConvert}
        disabled={!file || isProcessing}
        className="w-full"
        size="lg"
      >
        {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
        {isProcessing ? "Converting..." : "Convert to Word"}
      </Button>

      {extractedText && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold">Extracted text preview</h3>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={handleCopyText}>
                <ClipboardCopy className="mr-1 h-3.5 w-3.5" /> Copy text
              </Button>
              <Button size="sm" variant="outline" onClick={handleDownloadText}>
                <Download className="mr-1 h-3.5 w-3.5" /> Download .txt
              </Button>
              <Button size="sm" onClick={handleDownload}>
                <Download className="mr-1 h-3.5 w-3.5" /> Download .doc
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleProcessAnotherFile}
              >
                Process another file
              </Button>
            </div>
          </div>
          {clipboardStatus && (
            <p className="text-sm text-muted-foreground" role="status" aria-live="polite">
              {clipboardStatus}
            </p>
          )}
          <pre className="max-h-80 overflow-y-auto rounded-lg border bg-muted/30 p-3 text-xs whitespace-pre-wrap">
            {extractedText.slice(0, 4000)}
            {extractedText.length > 4000 ? "\n..." : ""}
          </pre>
        </div>
      )}
    </div>
  );
}
